﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice
{
    class Itemcode : Exception
    {
        public Itemcode(string message) : base(message) { }
    }
    class PnIcode : Exception
    {
        public PnIcode(string message) : base(message) { }
    }
    class ProductCode : Exception
    {
        public ProductCode(string message) : base(message) { }
    }
}
