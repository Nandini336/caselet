﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice
{
    class Program
    {
        public static List<Invoiced_Item> InList = new List<Invoiced_Item>();

        static void Main(string[] args)
        {
            string confirm;
            do
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("CHOOSE YOUR PREFERED OPTION "); 
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n1.Add new item \n2.Remove an item \n3.Calculate discount \n4.generate a bill \n5.Display all products \n6.UOM \n7.getdiscount \n8.getprice \n9.GetExchangePeriod");
                Console.ForegroundColor = ConsoleColor.White;
                int ch = Convert.ToInt16(Console.ReadLine());
                item it = new item();
                Invoiced_Item i = new Invoiced_Item();
                invoice a = new invoice();
                switch (ch)
                {

                    case 1:
                        i.add_item();
                        InList.Add(i);
                        break;
                    case 2:
                        i.remove_item();

                        break;
                    case 3:
                        i.calculate_disc();
                        InList.Add(i);

                        break;
                    case 4:
                        a.GenerateBill();
                        break;
                    case 5:
                        disp(); break;
                    case 6:
                        it.convert(); break;
                    case 7:
                        Console.WriteLine("enter the item code");
                        int icode = Convert.ToInt32(Console.ReadLine());
                        it.GetDiscount(icode); break;
                    case 8:
                        Console.WriteLine("enter the item code");
                        int Icode = Convert.ToInt32(Console.ReadLine());
                        it.GetPrice(Icode); break;
                    case 9:
                        Console.WriteLine("enter the item code");
                        int IIcode = Convert.ToInt32(Console.ReadLine());
                        it.GetXChangePeriod(IIcode); break;


                }
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Enter 'y' to continue");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;
                confirm = Console.ReadLine().ToUpper();
            } while (confirm == "Y");
            Console.ReadLine();

        }
        static void disp()
        {
            foreach (var i in InList)
            {
                Console.WriteLine($"item code is {i.item_code}");
                Console.WriteLine($"product code is {i.item_code}");
                Console.WriteLine($"price = {i.price}");
                Console.WriteLine($"Discount is {i.discount}");
                Console.WriteLine($"warranty is {i.warranty}");
                Console.WriteLine($"Xchange period is {i.xchange_period}");

                Console.WriteLine("-------------------");


            }
        }
    }
}
