﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice
{
    interface IItem
    {

        void GetDiscount(int ICode);

        void GetPrice(int ICode);

        void GetXChangePeriod(int ICode);

    }
}
