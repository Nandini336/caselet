﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice
{
    class invoice : Invoiced_Item
    {
        public string Code;
        public int Quantity;
        public float Amount;

        public void GenerateBill()
        {

            Console.WriteLine("Enter the product code");
            Code = Console.ReadLine();
            int count = 0;
            foreach (var item in Program.InList)
            {
                count++;
                try
                {
                    if (item.product_code == Code)
                    {

                        Console.WriteLine("enter item code");
                        int i = Convert.ToInt32(Console.ReadLine());
                        if (item.item_code == i)
                        {

                            Console.WriteLine("enter quantity ");
                            Quantity = Convert.ToInt32(Console.ReadLine());
                            Amount = item.newprice * Quantity;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("The price of the product is:");
                            Console.WriteLine(Amount);
                            Console.ForegroundColor = ConsoleColor.White;

                        }
                        else
                        {
                            
                            throw new PnIcode("item code and product code are not matching");
                            

                        }
                    }


                }
                catch (PnIcode e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ForegroundColor = ConsoleColor.White;

                }

            }


        }
    }

}
