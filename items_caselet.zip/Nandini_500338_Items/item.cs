﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice
{
    class item : IItem
    {
        public string product_code { get; set; }
        public int item_code { get; set; }
        public string size { get; set; }
        public int UOM { get; set; }

        public void add_item() { }

        public void remove_item() { }

        public void GetDiscount(int i)
        {
            
            foreach (var item in Program.InList)
            {
              
                if (item.item_code == i)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Discount is {item.discount} %");
                    Console.ForegroundColor = ConsoleColor.White;
                }

            }
        }
        public void GetPrice(int i)
        {
            
            foreach (var item in Program.InList)
            {
            
                if (item.item_code == i)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Item price is {item.price}rs");
                    Console.ForegroundColor = ConsoleColor.White;

                }

            }
        }
        public void GetXChangePeriod(int i)
        {
          
            foreach (var item in Program.InList)
            {
                
                if (item.item_code == i)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Exchange period is {item.xchange_period} ");
                    Console.ForegroundColor = ConsoleColor.White;

                }

            }
        }
        public void convert()
        {
            Console.WriteLine("enter the weight of the items in liters");
            UOM = Convert.ToInt32(Console.ReadLine());
            double scalingfactor = 1.1;
            double wt = UOM / scalingfactor;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("weight after conversion is:{0}", wt);
            Console.ForegroundColor = ConsoleColor.White;

        }

    }
}
