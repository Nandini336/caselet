﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice
{
    class Invoiced_Item : item
    {
        public int price { get; set; }
        public int discount { get; set; }
        public int warranty { get; set; }
        public int xchange_period { get; set; }
        public int disc { get; set; }
        public int newprice;
        public Invoiced_Item()
        {

        }

        public void add_item()
        {
            
            Console.WriteLine("Enter new item code");
            item_code = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the product code");
            product_code = Console.ReadLine();
            Console.WriteLine("Enter the price of the product ");
            price = Convert.ToInt32(Console.ReadLine());
            if (price > 0)
            {
                Console.WriteLine("Enter the discount for the product ");
                discount = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the warranty for the product ");
                warranty = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the period for exchanging the product ");
                xchange_period = Convert.ToInt32(Console.ReadLine());
                newprice = price - (price *discount / 100);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Item added succesfully");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (price < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The Minimum cost of the product should be above 1Rs");
                Console.ForegroundColor = ConsoleColor.White;

            }


        }

        public void remove_item()
        {
            try
            {
                Console.WriteLine("enter the item code");
                int temp = Convert.ToInt32(Console.ReadLine());
                int count = 0;
                foreach (var item in Program.InList)
                {
                    count++;
                    if (item.item_code == temp)
                    {

                        Program.InList.Remove(item);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Item deleted");
                        Console.ForegroundColor = ConsoleColor.White;

                    }
                    else if (count == Program.InList.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Enter the valid itemcode");
                        Console.ForegroundColor = ConsoleColor.White;

                    }
                    
                }
            }
            catch (Itemcode e)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(e.Message);
                Console.ForegroundColor = ConsoleColor.White;

            }

        }

        public void calculate_disc()
        {
            Console.WriteLine("enter the item code");
            int temp = Convert.ToInt32(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.InList)
            {
                count++;
                if (item.item_code == temp)
                {

                    item.price = item.price - (item.price * item.discount / 100);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("After discount the price is: {0}", item.price);
                    Console.ForegroundColor = ConsoleColor.White;

                }
            }
        }


    }
}
